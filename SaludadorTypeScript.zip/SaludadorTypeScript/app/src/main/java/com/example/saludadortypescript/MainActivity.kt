package com.example.saludadortypescript

import android.os.Bundle
import androidx.activity.ComponentActivity
import androidx.activity.compose.setContent
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.runtime.getValue
import androidx.compose.runtime.setValue
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.text.style.TextAlign
import androidx.compose.ui.tooling.preview.Preview
import androidx.compose.ui.unit.dp
import androidx.compose.ui.unit.sp
import com.example.saludadortypescript.ui.theme.SaludadorTypeScriptTheme

class MainActivity : ComponentActivity() {
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        // setContent es el punto de entrada para la UI de Jetpack Compose
        setContent {
            SaludadorTypeScriptTheme {
                // Surface es un contenedor que aplica el color de fondo del tema
                Surface(
                    modifier = Modifier.fillMaxSize(),
                    color = MaterialTheme.colorScheme.background
                ) {
                    SaludadorScreen()
                }
            }
        }
    }
}

@Composable
fun SaludadorScreen(modifier: Modifier = Modifier) {
    // Estado para almacenar el nombre introducido por el usuario
    var name by remember { mutableStateOf("") }
    // Estado para almacenar el mensaje que se mostrará en la interfaz
    var message by remember { mutableStateOf("") }

    // Column organiza los elementos verticalmente
    Column(
        modifier = modifier
            .fillMaxSize() // Ocupa todo el espacio disponible
            .padding(16.dp), // Padding alrededor del contenido
        horizontalAlignment = Alignment.CenterHorizontally, // Centra los elementos horizontalmente
        verticalArrangement = Arrangement.Center // Centra los elementos verticalmente
    ) {
        // Título de la aplicación
        Text(
            text = "Saludador Compose",
            fontSize = 32.sp,
            fontWeight = FontWeight.Bold,
            modifier = Modifier.padding(bottom = 40.dp)
        )

        // Campo de entrada para el nombre del usuario
        OutlinedTextField(
            value = name,
            onValueChange = { name = it },
            label = { Text("Escribe tu nombre aquí") },
            singleLine = true,
            modifier = Modifier
                .fillMaxWidth() // Ocupa todo el ancho
                .padding(bottom = 20.dp)
        )

        // Botón para ejecutar la acción de saludar
        Button(
            onClick = {
                // Lógica al pulsar el botón
                if (name.isBlank()) {
                    message = "Por favor, introduce tu nombre."
                } else {
                    message = "👋 Hola, $name"
                }
            },
            modifier = Modifier
                .fillMaxWidth()
                .height(50.dp)
                .padding(bottom = 20.dp)
        ) {
            Text(
                text = "Saludar",
                fontSize = 18.sp
            )
        }

        // Espacio para mostrar el mensaje de saludo o de error
        if (message.isNotEmpty()) {
            Text(
                text = message,
                fontSize = 18.sp,
                color = MaterialTheme.colorScheme.primary, // Usa el color primario del tema
                textAlign = TextAlign.Center
            )
        }
    }
}

@Preview(showBackground = true)
@Composable
fun SaludadorScreenPreview() {
    SaludadorTypeScriptTheme {
        SaludadorScreen()
    }
}
